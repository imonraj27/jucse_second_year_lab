
import string
letters = string.ascii_lowercase
print(letters)
print(list(enumerate(letters, 1)))
