
MyList = list(map(lambda x: x*5, range(1, 11)))

print(MyList)
